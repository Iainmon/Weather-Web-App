var weather = null;
var error = null;

    function printWeather(place, CorF) {

        //Loading screen
        //document.getElementById("body").innerHTML = '<img style="width:200px;height:200px;" src="loading.gif"><h1>Loading...</h1>';
        //delay(500000);

    var Place = place;
    //deleting "beta Tag"
    document.getElementById("beta").innerHTML = '';

    //setting up API
    var json = 'https://api.apixu.com/v1/current.json?key=39247fa6db6a42f0b8323903172710&q=' + place;
    var myAPI = new XMLHttpRequest();
    myAPI.open("GET", json, false);
    myAPI.send(null);
    var dat = JSON.parse(myAPI.response);

    //setup button
    document.getElementById("CorFDiv").innerHTML = '<button id="CorFButton" type="button" onclick="CorF" class="btn btn-warning"></button>';
    document.getElementById("CorFButton").innerHTML = 'Celsius';
    document.getElementById( "CorFButton" ).setAttribute( "onClick", "printWeather(" + "'" + 'C' + "'" + ");" );

    if (CorF == 'C') {
        //sets prefference to celsius
        document.getElementById("CorFDiv").innerHTML = '<button id="CorFButton" type="button" onclick="CorF" class="btn btn-warning"></button>';
        document.getElementById("CorFButton").innerHTML = 'Fahrenheit';
        document.getElementById( "CorFButton" ).setAttribute( "onClick", "printWeather(" + "'" + place + "'" + ", '" + 'F' + "'" + ");" );
        var temp = dat.current.temp_c;
        var feelsLike = dat.current.feelslike_c;
        var CorF = 'Celsius'
        /*
        document.getElementById("CorFButton").innerHTML = 'Fahrenheit';
        document.getElementById("CorFButton").onclick = "CorF('F');";
        createPage(place, temp, weather, feelsLike, humid, type);
        Debug('C');*/
    } else if (CorF == 'F') {
        //sets prefference to ferenhight
        document.getElementById("CorFDiv").innerHTML = '<button id="CorFButton" type="button" onclick="CorF" class="btn btn-warning"></button>';
        document.getElementById("CorFButton").innerHTML = 'Celsius';
        document.getElementById( "CorFButton" ).setAttribute( "onClick", "printWeather(" + "'" + place + "'" + ", '" + 'C' + "'" + ");" );
        var temp = dat.current.temp_f;
        var feelsLike = dat.current.feelslike_f;
        var CorF = 'Fahrenheit';
        /*document.getElementById("CorFButton").innerHTML = 'Celsius';
        document.getElementById("CorFButton").onclick = "CorF('C');";
        createPage(place, temp, weather, feelsLike, humid, type);
        Debug('F');*/
    }

    //setup data
    var humid = dat.current.humidity;
    var Place = dat.location.name;
    var weather = dat.current.condition.text;
    var day = dat.current.is_day;
    var weather = weather.toLocaleLowerCase();
    //
    if (weather == null) {
        errorPage();
    } else {

        //setup icon
        if (day == 1) {
            var icon = 'Icons/svg/' + weather + '.svg';
        } else if (day == 0) {
            var icon = 'Icons/svg/NIGHT/' + weather + '.svg';
        }


        //writing HTML
        document.getElementById("body").innerHTML = '<img style="width:200px;height:200px;" src="' + icon + '">' + '<h1>The weather in ' + Place + ' is currently ' + weather + '. The tempreture is ' + temp + '° ' + CorF + ', but feels like ' + feelsLike + '° ' + CorF + ', because of the ' + humid + '% humidity.</h1>' +
            '<button type="button" class="btn btn-default" onclick="location.reload(true);">Back</button>';
    }
}

function CorF(type) {

    if (type == 'C') {
        //sets prefference to celsius
        document.getElementById("CorFDiv").innerHTML = '<button id="CorFButton" type="button" onclick="CorF" class="btn btn-warning"></button>';
        document.getElementById("CorFButton").innerHTML = 'Fahrenheit';
        document.getElementById( "CorFButton" ).setAttribute( "onClick", "CorF(" + "'" + 'F' + "'" + ");" );
        /*
        document.getElementById("CorFButton").innerHTML = 'Fahrenheit';
        document.getElementById("CorFButton").onclick = "CorF('F');";
        createPage(place, temp, weather, feelsLike, humid, type);
        Debug('C');*/
    } else if (type == 'F') {
        //sets prefference to ferenhight
        document.getElementById("CorFDiv").innerHTML = '<button id="CorFButton" type="button" onclick="CorF" class="btn btn-warning"></button>';
        document.getElementById("CorFButton").innerHTML = 'Celsius';
        document.getElementById( "CorFButton" ).setAttribute( "onClick", "CorF(" + "'" + 'C' + "'" + ");" );
        /*document.getElementById("CorFButton").innerHTML = 'Celsius';
        document.getElementById("CorFButton").onclick = "CorF('C');";
        createPage(place, temp, weather, feelsLike, humid, type);
        Debug('F');*/
    }
    //updates page
    printWeather(Place, type)
}

//------------------------------FUNCTIONS-------------------------------------------

function errorPage() {
    document.getElementById("body").innerHTML = '<img style="width:200px;height:200px;" src="Icons/svg/warning.svg"><h1>Oops! There has been an error!</h1>' +
        '<button type="button" class="btn btn-default" onclick="location.reload(true);">Refresh Page</button>';
}

function Debug(print) {
    document.getElementById("debug").innerHTML = print;
}

function delay(mili) {
    setTimeout(delayfunc, mili);
}
function delayfunc() {
    document.getElementById("body").innerHTML = '<img style="width:200px;height:200px;" src="loading.gif"><h1>Loading...</h1>';
}



$("html").on("contextmenu",function(e){
    return false;
});

